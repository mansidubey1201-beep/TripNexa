@echo off
echo ============================================================
echo    YatraAI - AI Travel Booking Platform
echo    Quick Start Script for Windows
echo ============================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python from https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [OK] Python found
echo.

REM Navigate to backend directory
cd /d "%~dp0backend"

if not exist "app.py" (
    echo [ERROR] app.py not found in backend folder!
    pause
    exit /b 1
)

echo [OK] Backend files found
echo.

REM Install dependencies
echo Installing dependencies...
echo ----------------------------------------
pip install Flask==2.3.3 Flask-CORS==4.0.0 Flask-SQLAlchemy==3.0.5 Flask-JWT-Extended==4.5.3 Flask-Bcrypt==1.0.1 python-dotenv==1.0.0 requests==2.31.0 qrcode==7.4.2 Pillow==10.0.1 -q

if %errorlevel% neq 0 (
    echo [WARNING] Some packages may have failed to install
) else (
    echo [OK] All dependencies installed
)

echo.
echo ============================================================
echo    Starting YatraAI Backend Server...
echo ============================================================
echo.
echo    API URL: http://localhost:5000
echo    Health Check: http://localhost:5000/api/health
echo.
echo    Now open index.html in your browser!
echo.
echo    Press Ctrl+C to stop the server
echo ----------------------------------------
echo.

python app.py

pause
