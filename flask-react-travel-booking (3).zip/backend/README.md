# YatraAI - AI Travel Booking Backend

A comprehensive Python Flask backend for the YatraAI travel booking platform with authentication, bookings, and UPI payment integration.

## 🚀 Features

- **User Authentication**
  - Email/Phone registration
  - Password-based login
  - OTP-based login
  - JWT token authentication
  - Profile management

- **Travel Bookings**
  - Flight search & booking
  - Train search & booking (IRCTC style)
  - Hotel search & booking
  - Bus search & booking
  - Travel packages/combos

- **Payment System**
  - UPI QR code generation
  - UPI ID payment
  - Card payment simulation
  - Net banking simulation
  - Payment verification
  - Refund processing

- **AI Features**
  - AI chatbot for travel assistance
  - AI trip planner with itinerary generation
  - Destination recommendations

## 📦 Installation

### Prerequisites
- Python 3.8+
- pip (Python package manager)

### Setup

1. **Navigate to backend directory**
```bash
cd backend
```

2. **Create virtual environment**
```bash
python -m venv venv

# On Windows
venv\Scripts\activate

# On macOS/Linux
source venv/bin/activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Run the server**
```bash
python app.py
```

The server will start at `http://localhost:5000`

## 🔧 Configuration

Create a `.env` file in the backend directory:

```env
# Flask
SECRET_KEY=your-super-secret-key
FLASK_ENV=development

# JWT
JWT_SECRET_KEY=your-jwt-secret-key

# Database
DATABASE_URL=sqlite:///yatraai.db

# Razorpay (Optional - for production)
RAZORPAY_KEY_ID=rzp_test_xxxxx
RAZORPAY_KEY_SECRET=your_secret_key

# UPI
MERCHANT_UPI_ID=yatraai@upi
MERCHANT_NAME=YatraAI Travel

# SMS Gateway (Optional)
SMS_API_KEY=your_sms_api_key
```

## 📚 API Endpoints

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login with email/password |
| POST | `/api/auth/send-otp` | Send OTP to phone |
| POST | `/api/auth/verify-otp` | Verify OTP and login |
| GET | `/api/auth/profile` | Get user profile |
| PUT | `/api/auth/profile` | Update user profile |

### Flights

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/flights/search` | Search flights |

**Request Body:**
```json
{
  "origin": "DEL",
  "destination": "BOM",
  "date": "2024-02-15",
  "passengers": 2
}
```

### Trains

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/trains/search` | Search trains |

**Request Body:**
```json
{
  "origin": "NDLS",
  "destination": "BCT",
  "date": "2024-02-15",
  "class": "3A"
}
```

### Hotels

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/hotels/search` | Search hotels |

**Request Body:**
```json
{
  "location": "Jaipur",
  "check_in": "2024-02-15",
  "check_out": "2024-02-17",
  "guests": 2
}
```

### Packages

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/packages` | Get all travel packages |

### Bookings

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/bookings` | Create booking |
| GET | `/api/bookings` | Get user bookings |
| GET | `/api/bookings/<id>` | Get booking details |
| POST | `/api/bookings/<id>/cancel` | Cancel booking |

### Payments

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/payments/initiate` | Initiate payment |
| POST | `/api/payments/verify` | Verify payment |
| POST | `/api/payments/generate-qr` | Generate UPI QR code |

**Generate QR Request:**
```json
{
  "amount": 34499,
  "booking_id": "YAI240115ABC123"
}
```

**Response:**
```json
{
  "success": true,
  "qr_code": "data:image/png;base64,...",
  "upi_id": "yatraai@upi",
  "amount": 34499
}
```

### AI Assistant

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/ai/chat` | Chat with AI assistant |
| POST | `/api/ai/trip-plan` | Generate AI trip plan |

**Chat Request:**
```json
{
  "message": "Best time to visit Ladakh?"
}
```

**Trip Plan Request:**
```json
{
  "destination": "jaipur",
  "duration": 7,
  "budget": "comfort",
  "travelers": 2,
  "preferences": ["heritage", "food"]
}
```

## 🗄️ Database Models

### User
- id, email, phone, password_hash, full_name
- profile fields (dob, gender, address, city, state)
- is_active, is_verified

### Booking
- booking_id, user_id, booking_type
- origin, destination, travel_date, return_date
- num_travelers, traveler_details
- base_price, taxes, discount, total_price
- status (pending, confirmed, cancelled, completed)

### Payment
- payment_id, booking_id, user_id
- amount, currency, payment_method
- upi_id, upi_transaction_id
- card_last_four, card_brand
- status (pending, completed, failed, refunded)

## 🔐 Authentication

The API uses JWT (JSON Web Tokens) for authentication.

**Headers for protected routes:**
```
Authorization: Bearer <access_token>
```

## 💳 Payment Integration

### UPI Payment Flow

1. **Initiate Payment** → Returns QR code and UPI details
2. **User scans QR** → Pays via GPay/PhonePe/Paytm
3. **Verify Payment** → Confirm with transaction ID
4. **Booking Confirmed** → Status updated to 'confirmed'

### Supported Payment Methods

- **UPI**: GPay, PhonePe, Paytm, BHIM, etc.
- **Cards**: Visa, Mastercard, RuPay
- **Net Banking**: All major Indian banks
- **Wallets**: Paytm, MobiKwik, Amazon Pay

## 🧪 Testing

Run with demo mode (no external APIs):
```bash
python app.py
```

For production with Razorpay:
```bash
RAZORPAY_KEY_ID=your_key RAZORPAY_KEY_SECRET=your_secret python app.py
```

## 📱 Frontend Integration

The frontend (`index.html`) automatically connects to `http://localhost:5000/api`

To use a different API URL, update in the frontend:
```javascript
const API_URL = 'http://your-api-url/api';
```

## 🚀 Deployment

### Using Gunicorn (Production)
```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Using Docker
```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

## 📄 License

MIT License - Feel free to use for personal or commercial projects.

## 🤝 Support

For issues or feature requests, please create an issue on GitHub.

---

Made with ❤️ for Indian Travelers | YatraAI 2024
