"""
YatraAI - AI Travel Booking Backend
Main Flask Application
"""

from flask import Flask, jsonify, request, send_file
from flask_cors import CORS
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, create_refresh_token, jwt_required, get_jwt_identity
from datetime import datetime, timedelta
import json
import random
import string
import qrcode
import io
import base64

from config import config
from models import db, User, Booking, Payment, Flight, Train, Hotel, TravelPackage, SavedTraveler, OTP

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(config['development'])

# Initialize extensions
CORS(app, origins=['*'], supports_credentials=True)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)
db.init_app(app)

# ==================== HELPER FUNCTIONS ====================

def generate_booking_id():
    """Generate unique booking ID"""
    prefix = 'YAI'
    timestamp = datetime.now().strftime('%y%m%d')
    random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"{prefix}{timestamp}{random_str}"

def generate_payment_id():
    """Generate unique payment ID"""
    return f"PAY{''.join(random.choices(string.digits, k=12))}"

def generate_otp():
    """Generate 6-digit OTP"""
    return ''.join(random.choices(string.digits, k=6))

def generate_upi_qr(amount, booking_id, upi_id="yatraai@upi"):
    """Generate UPI QR code"""
    upi_string = f"upi://pay?pa={upi_id}&pn=YatraAI&am={amount}&tn=Booking-{booking_id}&cu=INR"
    
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(upi_string)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert to base64
    buffer = io.BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    img_base64 = base64.b64encode(buffer.getvalue()).decode()
    
    return f"data:image/png;base64,{img_base64}"

# ==================== AUTH ROUTES ====================

@app.route('/api/auth/register', methods=['POST'])
def register():
    """Register new user"""
    try:
        data = request.json
        
        # Validate required fields
        required_fields = ['email', 'phone', 'password', 'full_name']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'success': False, 'error': f'{field} is required'}), 400
        
        # Check if user exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'success': False, 'error': 'Email already registered'}), 400
        
        if User.query.filter_by(phone=data['phone']).first():
            return jsonify({'success': False, 'error': 'Phone number already registered'}), 400
        
        # Create user
        password_hash = bcrypt.generate_password_hash(data['password']).decode('utf-8')
        
        user = User(
            email=data['email'],
            phone=data['phone'],
            password_hash=password_hash,
            full_name=data['full_name'],
            city=data.get('city'),
            state=data.get('state')
        )
        
        db.session.add(user)
        db.session.commit()
        
        # Generate tokens
        access_token = create_access_token(identity=user.id)
        refresh_token = create_refresh_token(identity=user.id)
        
        return jsonify({
            'success': True,
            'message': 'Registration successful',
            'user': user.to_dict(),
            'access_token': access_token,
            'refresh_token': refresh_token
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/auth/login', methods=['POST'])
def login():
    """Login user"""
    try:
        data = request.json
        
        email_or_phone = data.get('email_or_phone')
        password = data.get('password')
        
        if not email_or_phone or not password:
            return jsonify({'success': False, 'error': 'Email/Phone and password required'}), 400
        
        # Find user by email or phone
        user = User.query.filter(
            (User.email == email_or_phone) | (User.phone == email_or_phone)
        ).first()
        
        if not user or not bcrypt.check_password_hash(user.password_hash, password):
            return jsonify({'success': False, 'error': 'Invalid credentials'}), 401
        
        if not user.is_active:
            return jsonify({'success': False, 'error': 'Account is deactivated'}), 401
        
        # Generate tokens
        access_token = create_access_token(identity=user.id)
        refresh_token = create_refresh_token(identity=user.id)
        
        return jsonify({
            'success': True,
            'message': 'Login successful',
            'user': user.to_dict(),
            'access_token': access_token,
            'refresh_token': refresh_token
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/auth/send-otp', methods=['POST'])
def send_otp():
    """Send OTP for login/verification"""
    try:
        data = request.json
        phone = data.get('phone')
        purpose = data.get('purpose', 'login')
        
        if not phone:
            return jsonify({'success': False, 'error': 'Phone number required'}), 400
        
        # Generate OTP
        otp_code = generate_otp()
        expires_at = datetime.utcnow() + timedelta(minutes=10)
        
        # Save OTP
        otp = OTP(
            phone_or_email=phone,
            otp_code=otp_code,
            purpose=purpose,
            expires_at=expires_at
        )
        db.session.add(otp)
        db.session.commit()
        
        # In production, send SMS here
        # For demo, we'll return the OTP
        return jsonify({
            'success': True,
            'message': 'OTP sent successfully',
            'otp': otp_code,  # Remove in production
            'expires_in': 600
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/auth/verify-otp', methods=['POST'])
def verify_otp():
    """Verify OTP and login"""
    try:
        data = request.json
        phone = data.get('phone')
        otp_code = data.get('otp')
        
        if not phone or not otp_code:
            return jsonify({'success': False, 'error': 'Phone and OTP required'}), 400
        
        # Find valid OTP
        otp = OTP.query.filter_by(
            phone_or_email=phone,
            otp_code=otp_code,
            is_used=False
        ).first()
        
        if not otp or otp.expires_at < datetime.utcnow():
            return jsonify({'success': False, 'error': 'Invalid or expired OTP'}), 400
        
        # Mark OTP as used
        otp.is_used = True
        db.session.commit()
        
        # Find or create user
        user = User.query.filter_by(phone=phone).first()
        
        if not user:
            return jsonify({
                'success': True,
                'new_user': True,
                'message': 'OTP verified. Please complete registration.'
            })
        
        # Generate tokens
        access_token = create_access_token(identity=user.id)
        refresh_token = create_refresh_token(identity=user.id)
        
        return jsonify({
            'success': True,
            'message': 'Login successful',
            'user': user.to_dict(),
            'access_token': access_token,
            'refresh_token': refresh_token
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/auth/profile', methods=['GET'])
@jwt_required()
def get_profile():
    """Get current user profile"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404
        
        return jsonify({
            'success': True,
            'user': user.to_dict()
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/auth/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    """Update user profile"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404
        
        data = request.json
        
        # Update allowed fields
        allowed_fields = ['full_name', 'date_of_birth', 'gender', 'address', 'city', 'state', 'pincode']
        for field in allowed_fields:
            if field in data:
                setattr(user, field, data[field])
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Profile updated successfully',
            'user': user.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== FLIGHT ROUTES ====================

@app.route('/api/flights/search', methods=['POST'])
def search_flights():
    """Search for flights"""
    try:
        data = request.json
        origin = data.get('origin', 'DEL')
        destination = data.get('destination', 'BOM')
        date = data.get('date')
        passengers = data.get('passengers', 1)
        
        # Sample flight data (in production, query from DB or external API)
        flights = [
            {
                'id': 'AI101',
                'airline': 'Air India',
                'airline_logo': '🛫',
                'flight_number': 'AI-101',
                'origin': origin,
                'destination': destination,
                'departure': '06:00',
                'arrival': '08:15',
                'duration': '2h 15m',
                'price': 4599,
                'seats_available': 45,
                'class': 'Economy',
                'stops': 'Non-stop',
                'baggage': '15kg + 7kg',
                'meal': 'Complimentary'
            },
            {
                'id': 'UK835',
                'airline': 'Vistara',
                'airline_logo': '✈️',
                'flight_number': 'UK-835',
                'origin': origin,
                'destination': destination,
                'departure': '08:30',
                'arrival': '10:40',
                'duration': '2h 10m',
                'price': 5299,
                'seats_available': 32,
                'class': 'Economy',
                'stops': 'Non-stop',
                'baggage': '15kg + 7kg',
                'meal': 'Complimentary'
            },
            {
                'id': '6E205',
                'airline': 'IndiGo',
                'airline_logo': '🔵',
                'flight_number': '6E-205',
                'origin': origin,
                'destination': destination,
                'departure': '10:15',
                'arrival': '12:30',
                'duration': '2h 15m',
                'price': 3899,
                'seats_available': 78,
                'class': 'Economy',
                'stops': 'Non-stop',
                'baggage': '15kg + 7kg',
                'meal': 'Paid'
            },
            {
                'id': 'SG412',
                'airline': 'SpiceJet',
                'airline_logo': '🔴',
                'flight_number': 'SG-412',
                'origin': origin,
                'destination': destination,
                'departure': '14:00',
                'arrival': '16:20',
                'duration': '2h 20m',
                'price': 3599,
                'seats_available': 56,
                'class': 'Economy',
                'stops': 'Non-stop',
                'baggage': '15kg + 7kg',
                'meal': 'Paid'
            },
            {
                'id': 'G8142',
                'airline': 'Go First',
                'airline_logo': '🟢',
                'flight_number': 'G8-142',
                'origin': origin,
                'destination': destination,
                'departure': '18:45',
                'arrival': '21:00',
                'duration': '2h 15m',
                'price': 3299,
                'seats_available': 23,
                'class': 'Economy',
                'stops': 'Non-stop',
                'baggage': '15kg + 7kg',
                'meal': 'Paid'
            }
        ]
        
        return jsonify({
            'success': True,
            'flights': flights,
            'search_params': {
                'origin': origin,
                'destination': destination,
                'date': date,
                'passengers': passengers
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== TRAIN ROUTES ====================

@app.route('/api/trains/search', methods=['POST'])
def search_trains():
    """Search for trains"""
    try:
        data = request.json
        origin = data.get('origin', 'NDLS')
        destination = data.get('destination', 'BCT')
        date = data.get('date')
        train_class = data.get('class', '3A')
        
        trains = [
            {
                'id': '12952',
                'name': 'Mumbai Rajdhani Express',
                'number': '12952',
                'origin': origin,
                'destination': destination,
                'departure': '16:55',
                'arrival': '08:35',
                'duration': '15h 40m',
                'days': 'Daily',
                'classes': {
                    '1A': {'price': 4855, 'seats': 12},
                    '2A': {'price': 2880, 'seats': 24},
                    '3A': {'price': 2155, 'seats': 45}
                }
            },
            {
                'id': '12954',
                'name': 'August Kranti Rajdhani',
                'number': '12954',
                'origin': origin,
                'destination': destination,
                'departure': '17:40',
                'arrival': '10:55',
                'duration': '17h 15m',
                'days': 'Daily',
                'classes': {
                    '1A': {'price': 4595, 'seats': 8},
                    '2A': {'price': 2720, 'seats': 32},
                    '3A': {'price': 1995, 'seats': 64}
                }
            },
            {
                'id': '12138',
                'name': 'Punjab Mail',
                'number': '12138',
                'origin': origin,
                'destination': destination,
                'departure': '21:25',
                'arrival': '19:10',
                'duration': '21h 45m',
                'days': 'Daily',
                'classes': {
                    '2A': {'price': 1855, 'seats': 28},
                    '3A': {'price': 1295, 'seats': 72},
                    'SL': {'price': 495, 'seats': 180}
                }
            },
            {
                'id': '22222',
                'name': 'Hazrat Nizamuddin CSMT SF',
                'number': '22222',
                'origin': origin,
                'destination': destination,
                'departure': '06:10',
                'arrival': '23:15',
                'duration': '17h 05m',
                'days': 'Tue, Thu, Sat',
                'classes': {
                    '3A': {'price': 1450, 'seats': 48},
                    'SL': {'price': 545, 'seats': 220},
                    '2S': {'price': 325, 'seats': 150}
                }
            }
        ]
        
        return jsonify({
            'success': True,
            'trains': trains,
            'search_params': {
                'origin': origin,
                'destination': destination,
                'date': date,
                'class': train_class
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== HOTEL ROUTES ====================

@app.route('/api/hotels/search', methods=['POST'])
def search_hotels():
    """Search for hotels"""
    try:
        data = request.json
        location = data.get('location', 'Jaipur')
        check_in = data.get('check_in')
        check_out = data.get('check_out')
        guests = data.get('guests', 2)
        
        hotels = [
            {
                'id': 'HT001',
                'name': 'Taj Rambagh Palace',
                'city': location,
                'address': 'Bhawani Singh Road, Jaipur',
                'rating': 4.9,
                'reviews': 2850,
                'price': 18500,
                'original_price': 22000,
                'amenities': ['Pool', 'Spa', 'WiFi', 'Restaurant', 'Heritage', 'Gym'],
                'room_type': 'Deluxe Room',
                'image': 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400',
                'cancellation': 'Free cancellation till 24h before'
            },
            {
                'id': 'HT002',
                'name': 'ITC Rajputana',
                'city': location,
                'address': 'Palace Road, Jaipur',
                'rating': 4.7,
                'reviews': 1950,
                'price': 8999,
                'original_price': 11000,
                'amenities': ['Pool', 'Gym', 'WiFi', 'Multi-cuisine', 'Spa'],
                'room_type': 'Superior Room',
                'image': 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400',
                'cancellation': 'Free cancellation till 48h before'
            },
            {
                'id': 'HT003',
                'name': 'Hotel Clarks Amer',
                'city': location,
                'address': 'JLN Marg, Jaipur',
                'rating': 4.4,
                'reviews': 1420,
                'price': 5499,
                'original_price': 6500,
                'amenities': ['Pool', 'WiFi', 'Restaurant', 'Parking'],
                'room_type': 'Standard Room',
                'image': 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=400',
                'cancellation': 'Non-refundable'
            },
            {
                'id': 'HT004',
                'name': 'Zostel Jaipur',
                'city': location,
                'address': 'C-Scheme, Jaipur',
                'rating': 4.5,
                'reviews': 890,
                'price': 899,
                'original_price': 1200,
                'amenities': ['WiFi', 'Cafe', 'Common Area', 'Lockers'],
                'room_type': 'Dorm Bed',
                'image': 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400',
                'cancellation': 'Free cancellation'
            }
        ]
        
        return jsonify({
            'success': True,
            'hotels': hotels,
            'search_params': {
                'location': location,
                'check_in': check_in,
                'check_out': check_out,
                'guests': guests
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== PACKAGES/COMBOS ROUTES ====================

@app.route('/api/packages', methods=['GET'])
def get_packages():
    """Get all travel packages"""
    packages = [
        {
            'id': 'PKG001',
            'name': 'Royal Rajasthan Circuit',
            'description': 'Jaipur → Jodhpur → Udaipur with palace stays & desert safari',
            'destination': 'Rajasthan',
            'duration': '6N/7D',
            'price': 34499,
            'original_price': 45999,
            'discount': 25,
            'rating': 4.9,
            'reviews': 1250,
            'includes': ['Flights', 'Heritage Hotels', 'Desert Safari', 'All Meals', 'Sightseeing', 'Transfers'],
            'image': 'https://images.unsplash.com/photo-1599661046289-e31897846e41?w=600',
            'highlights': ['Amber Fort', 'Mehrangarh Fort', 'Lake Pichola', 'Jaisalmer Desert']
        },
        {
            'id': 'PKG002',
            'name': 'Kerala Bliss Package',
            'description': 'Kochi → Munnar → Alleppey with houseboat stay',
            'destination': 'Kerala',
            'duration': '5N/6D',
            'price': 28999,
            'original_price': 38999,
            'discount': 26,
            'rating': 4.8,
            'reviews': 956,
            'includes': ['Flights', 'Hotels', 'Houseboat', 'Ayurveda Spa', 'Breakfast', 'Transfers'],
            'image': 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=600',
            'highlights': ['Munnar Tea Gardens', 'Alleppey Backwaters', 'Kathakali Show', 'Spice Plantation']
        },
        {
            'id': 'PKG003',
            'name': 'Goa Beach Getaway',
            'description': 'North & South Goa beaches, water sports & nightlife',
            'destination': 'Goa',
            'duration': '4N/5D',
            'price': 17999,
            'original_price': 24999,
            'discount': 28,
            'rating': 4.7,
            'reviews': 2100,
            'includes': ['Flights', 'Beach Resort', 'Water Sports', 'Transfers', 'Breakfast'],
            'image': 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=600',
            'highlights': ['Baga Beach', 'Dudhsagar Falls', 'Old Goa Churches', 'Casino Night']
        },
        {
            'id': 'PKG004',
            'name': 'Ladakh Expedition',
            'description': 'Leh → Nubra → Pangong with bike tours & camping',
            'destination': 'Ladakh',
            'duration': '7N/8D',
            'price': 42999,
            'original_price': 55999,
            'discount': 23,
            'rating': 4.9,
            'reviews': 789,
            'includes': ['Flights', 'Hotels', 'Camps', 'Bike Tour', 'All Meals', 'Permits'],
            'image': 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=600',
            'highlights': ['Pangong Lake', 'Khardung La', 'Nubra Valley', 'Monasteries']
        },
        {
            'id': 'PKG005',
            'name': 'Golden Triangle Tour',
            'description': 'Delhi → Agra → Jaipur with Taj Mahal sunrise visit',
            'destination': 'North India',
            'duration': '5N/6D',
            'price': 24999,
            'original_price': 32999,
            'discount': 24,
            'rating': 4.9,
            'reviews': 3500,
            'includes': ['AC Car', '4-Star Hotels', 'All Entry Tickets', 'Guide', 'Breakfast'],
            'image': 'https://images.unsplash.com/photo-1564507592333-c60657eea523?w=600',
            'highlights': ['Taj Mahal Sunrise', 'Amber Fort', 'Qutub Minar', 'India Gate']
        },
        {
            'id': 'PKG006',
            'name': 'Andaman Paradise',
            'description': 'Port Blair → Havelock → Neil Island adventure',
            'destination': 'Andaman',
            'duration': '5N/6D',
            'price': 36999,
            'original_price': 48999,
            'discount': 25,
            'rating': 4.8,
            'reviews': 1800,
            'includes': ['Flights', 'Beach Resort', 'Scuba Diving', 'Ferry', 'Breakfast'],
            'image': 'https://images.unsplash.com/photo-1586508577428-120d6b072945?w=600',
            'highlights': ['Radhanagar Beach', 'Cellular Jail', 'Scuba Diving', 'Glass Boat Ride']
        }
    ]
    
    return jsonify({'success': True, 'packages': packages})


# ==================== BOOKING ROUTES ====================

@app.route('/api/bookings', methods=['POST'])
@jwt_required()
def create_booking():
    """Create a new booking"""
    try:
        user_id = get_jwt_identity()
        data = request.json
        
        # Generate booking ID
        booking_id = generate_booking_id()
        
        # Calculate pricing
        base_price = data.get('base_price', 0)
        num_travelers = data.get('num_travelers', 1)
        subtotal = base_price * num_travelers
        taxes = subtotal * 0.05  # 5% GST
        discount = data.get('discount', 0)
        total_price = subtotal + taxes - discount
        
        # Create booking
        booking = Booking(
            booking_id=booking_id,
            user_id=user_id,
            booking_type=data.get('booking_type'),
            origin=data.get('origin'),
            destination=data.get('destination'),
            travel_date=datetime.fromisoformat(data.get('travel_date')),
            return_date=datetime.fromisoformat(data.get('return_date')) if data.get('return_date') else None,
            num_travelers=num_travelers,
            traveler_details=json.dumps(data.get('travelers', [])),
            base_price=base_price,
            taxes=taxes,
            discount=discount,
            total_price=total_price,
            booking_details=json.dumps(data.get('details', {})),
            status='pending'
        )
        
        db.session.add(booking)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Booking created successfully',
            'booking': booking.to_dict(),
            'payment_required': total_price
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/bookings', methods=['GET'])
@jwt_required()
def get_bookings():
    """Get all bookings for current user"""
    try:
        user_id = get_jwt_identity()
        bookings = Booking.query.filter_by(user_id=user_id).order_by(Booking.created_at.desc()).all()
        
        return jsonify({
            'success': True,
            'bookings': [b.to_dict() for b in bookings]
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/bookings/<booking_id>', methods=['GET'])
@jwt_required()
def get_booking(booking_id):
    """Get booking details"""
    try:
        user_id = get_jwt_identity()
        booking = Booking.query.filter_by(booking_id=booking_id, user_id=user_id).first()
        
        if not booking:
            return jsonify({'success': False, 'error': 'Booking not found'}), 404
        
        return jsonify({
            'success': True,
            'booking': booking.to_dict()
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/bookings/<booking_id>/cancel', methods=['POST'])
@jwt_required()
def cancel_booking(booking_id):
    """Cancel a booking"""
    try:
        user_id = get_jwt_identity()
        booking = Booking.query.filter_by(booking_id=booking_id, user_id=user_id).first()
        
        if not booking:
            return jsonify({'success': False, 'error': 'Booking not found'}), 404
        
        if booking.status == 'cancelled':
            return jsonify({'success': False, 'error': 'Booking already cancelled'}), 400
        
        booking.status = 'cancelled'
        
        # Process refund if payment was made
        if booking.payment and booking.payment.status == 'completed':
            refund_amount = booking.total_price * 0.9  # 90% refund
            booking.payment.refund_amount = refund_amount
            booking.payment.refund_status = 'pending'
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Booking cancelled successfully',
            'refund_amount': refund_amount if booking.payment else 0
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== PAYMENT ROUTES ====================

@app.route('/api/payments/initiate', methods=['POST'])
@jwt_required()
def initiate_payment():
    """Initiate payment for a booking"""
    try:
        user_id = get_jwt_identity()
        data = request.json
        
        booking_id = data.get('booking_id')
        payment_method = data.get('payment_method')  # upi, card, netbanking, wallet
        
        booking = Booking.query.filter_by(booking_id=booking_id, user_id=user_id).first()
        
        if not booking:
            return jsonify({'success': False, 'error': 'Booking not found'}), 404
        
        # Generate payment ID
        payment_id = generate_payment_id()
        
        # Create payment record
        payment = Payment(
            payment_id=payment_id,
            booking_id=booking.id,
            user_id=user_id,
            amount=booking.total_price,
            payment_method=payment_method,
            status='pending'
        )
        
        db.session.add(payment)
        db.session.commit()
        
        response = {
            'success': True,
            'payment_id': payment_id,
            'amount': booking.total_price,
            'booking_id': booking_id
        }
        
        # Generate UPI QR if payment method is UPI
        if payment_method == 'upi':
            qr_code = generate_upi_qr(booking.total_price, booking_id)
            response['qr_code'] = qr_code
            response['upi_id'] = 'yatraai@upi'
            response['upi_deeplink'] = f"upi://pay?pa=yatraai@upi&pn=YatraAI&am={booking.total_price}&tn=Booking-{booking_id}&cu=INR"
        
        return jsonify(response)
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/payments/verify', methods=['POST'])
@jwt_required()
def verify_payment():
    """Verify payment completion"""
    try:
        user_id = get_jwt_identity()
        data = request.json
        
        payment_id = data.get('payment_id')
        transaction_id = data.get('transaction_id')  # UPI transaction ID or card transaction ID
        
        payment = Payment.query.filter_by(payment_id=payment_id, user_id=user_id).first()
        
        if not payment:
            return jsonify({'success': False, 'error': 'Payment not found'}), 404
        
        # In production, verify with payment gateway
        # For demo, we'll mark as completed
        
        payment.status = 'completed'
        payment.upi_transaction_id = transaction_id
        payment.completed_at = datetime.utcnow()
        
        # Update booking status
        booking = payment.booking
        booking.status = 'confirmed'
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Payment verified successfully',
            'payment': payment.to_dict(),
            'booking': booking.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/payments/upi-callback', methods=['POST'])
def upi_callback():
    """Handle UPI payment callback (webhook)"""
    try:
        data = request.json
        
        # Verify callback authenticity
        # In production, verify signature from payment gateway
        
        payment_id = data.get('payment_id')
        status = data.get('status')
        transaction_id = data.get('transaction_id')
        
        payment = Payment.query.filter_by(payment_id=payment_id).first()
        
        if payment:
            payment.status = 'completed' if status == 'success' else 'failed'
            payment.upi_transaction_id = transaction_id
            payment.completed_at = datetime.utcnow()
            
            if status == 'success':
                payment.booking.status = 'confirmed'
            
            db.session.commit()
        
        return jsonify({'success': True})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/payments/generate-qr', methods=['POST'])
def generate_qr():
    """Generate UPI QR code"""
    try:
        data = request.json
        amount = data.get('amount')
        booking_id = data.get('booking_id', 'DIRECT')
        
        qr_code = generate_upi_qr(amount, booking_id)
        
        return jsonify({
            'success': True,
            'qr_code': qr_code,
            'upi_id': 'yatraai@upi',
            'amount': amount
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== AI ASSISTANT ROUTES ====================

@app.route('/api/ai/chat', methods=['POST'])
def ai_chat():
    """AI chatbot for travel assistance"""
    try:
        data = request.json
        message = data.get('message', '').lower()
        
        # AI response logic
        responses = {
            'ladakh': """🏔️ **Ladakh - Land of High Passes**

**Best Time:** June to September (roads open)

**Budget Tips:**
• Shared cabs from Leh: ₹500-800/day
• Homestays: ₹800-1200/night
• Carry altitude sickness medicine

**Must Do:**
• Pangong Lake camping
• Khardung La pass
• Monastery visits

**Pro Tip:** Acclimatize in Leh for 2 days!""",
            
            'goa': """🏖️ **Goa - Beach Paradise**

**Best Time:** November to February

**Budget Tips:**
• Rent a scooty: ₹300-400/day
• Stay in Anjuna/Vagator for budget options
• Eat at beach shacks

**North vs South:**
• North = Parties & markets
• South = Peace & luxury

**Must Try:** Fish curry rice & Feni! 🍻""",
            
            'kerala': """🌴 **Kerala - God's Own Country**

**Best Time:** September to March

**Budget Tips:**
• Shared houseboats: ₹6000-8000
• Use KSRTC buses
• Try Sadya meals: ₹150-200

**Suggested Route:**
Kochi (2D) → Munnar (2D) → Thekkady (1D) → Alleppey (1N houseboat)

**Don't Miss:** Kathakali show & Ayurvedic massage! 💆""",
            
            'jaipur': """🏰 **Jaipur - The Pink City**

**Best Time:** October to March

**Budget Tips:**
• Auto-rickshaws with meter
• Composite ticket for all forts
• Shop at Bapu Bazaar, bargain 40-50%

**Must Visit:**
• Amber Fort (go at 8 AM)
• Hawa Mahal at sunset
• Nahargarh for city views

**Food:** Dal Baati Churma is a must! 🍛""",
            
            'budget': """💰 **Budget Travel Tips for India**

**Transport:**
• Book trains via IRCTC - 2 months advance
• Use Sleeper class for overnight
• RedBus for comfortable travel

**Stay:**
• Zostel/Hostels: ₹400-600
• OYO budget: ₹800-1200
• Homestays in small towns

**Food:**
• Eat at local dhabas
• Thali meals - filling & cheap
• Street food in busy areas is safe

**Golden Rule:** Travel in shoulder season for 30-40% savings!"""
        }
        
        # Find matching response
        response = None
        for key, value in responses.items():
            if key in message:
                response = value
                break
        
        if not response:
            response = """🙏 **Namaste! I'm YatraBot**

I can help you with:
• 🗺️ Destination recommendations
• 💰 Budget planning
• 🍛 Food & restaurant suggestions
• 🏨 Hotel recommendations
• 🚂 Travel booking tips
• 📅 Best time to visit

**Popular Destinations:**
• Rajasthan: Heritage & palaces
• Goa: Beaches & parties
• Kerala: Backwaters & nature
• Ladakh: Mountains & adventure
• Varanasi: Spiritual experience

What would you like to know? 😊"""
        
        return jsonify({
            'success': True,
            'response': response
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/ai/trip-plan', methods=['POST'])
def generate_trip_plan():
    """Generate AI trip plan"""
    try:
        data = request.json
        destination = data.get('destination', 'jaipur')
        duration = int(data.get('duration', 7))
        budget = data.get('budget', 'comfort')
        travelers = int(data.get('travelers', 2))
        preferences = data.get('preferences', [])
        
        # Destination info database
        destinations = {
            'jaipur': {
                'name': 'Jaipur',
                'state': 'Rajasthan',
                'best_time': 'October to March',
                'language': 'Hindi, Rajasthani',
                'must_visit': ['Amber Fort', 'Hawa Mahal', 'City Palace', 'Jantar Mantar', 'Nahargarh Fort'],
                'food': ['Dal Baati Churma', 'Laal Maas', 'Pyaaz Kachori', 'Ghewar', 'Mirchi Bada'],
                'tips': ['Bargain at markets', 'Visit forts early morning', 'Try local Rajasthani thali']
            },
            'goa': {
                'name': 'Goa',
                'state': 'Goa',
                'best_time': 'November to February',
                'language': 'Konkani, Hindi, English',
                'must_visit': ['Baga Beach', 'Basilica of Bom Jesus', 'Fort Aguada', 'Dudhsagar Falls'],
                'food': ['Fish Curry Rice', 'Bebinca', 'Vindaloo', 'Xacuti', 'Feni'],
                'tips': ['Rent a scooty', 'North Goa for parties', 'South Goa for peace']
            },
            'kerala': {
                'name': 'Kerala',
                'state': 'Kerala',
                'best_time': 'September to March',
                'language': 'Malayalam, English',
                'must_visit': ['Alleppey Backwaters', 'Munnar', 'Kumarakom', 'Thekkady', 'Fort Kochi'],
                'food': ['Appam & Stew', 'Puttu & Kadala', 'Fish Molee', 'Kerala Sadya'],
                'tips': ['Book houseboat early', 'Try Ayurvedic massage', 'Visit during Onam']
            },
            'ladakh': {
                'name': 'Ladakh',
                'state': 'Ladakh (UT)',
                'best_time': 'June to September',
                'language': 'Ladakhi, Hindi',
                'must_visit': ['Pangong Lake', 'Nubra Valley', 'Khardung La', 'Thiksey Monastery'],
                'food': ['Momos', 'Thukpa', 'Skyu', 'Butter Tea'],
                'tips': ['Acclimatize for 2 days', 'Carry altitude sickness medicine', 'Book permits in advance']
            }
        }
        
        dest_info = destinations.get(destination, destinations['jaipur'])
        
        # Budget calculation
        budget_per_day = {'budget': 2000, 'comfort': 5000, 'premium': 10000, 'luxury': 20000}
        daily_budget = budget_per_day.get(budget, 5000)
        total_budget = daily_budget * duration * travelers
        
        # Generate itinerary
        itinerary = []
        activities = ['Morning: Local sightseeing', 'Afternoon: Cultural exploration', 'Evening: Leisure & dinner']
        
        for day in range(1, duration + 1):
            itinerary.append({
                'day': day,
                'title': f"Day {day} - {dest_info['name']}",
                'morning': f"Visit {dest_info['must_visit'][(day-1) % len(dest_info['must_visit'])]}",
                'afternoon': 'Local exploration & lunch',
                'evening': f"Try {dest_info['food'][(day-1) % len(dest_info['food'])]} for dinner"
            })
        
        return jsonify({
            'success': True,
            'trip_plan': {
                'destination': dest_info['name'],
                'state': dest_info['state'],
                'duration': f'{duration} days',
                'travelers': travelers,
                'budget_level': budget,
                'total_budget': total_budget,
                'best_time': dest_info['best_time'],
                'language': dest_info['language'],
                'itinerary': itinerary,
                'must_visit': dest_info['must_visit'],
                'food': dest_info['food'],
                'tips': dest_info['tips']
            }
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== UTILITY ROUTES ====================

@app.route('/')
def home():
    """API Home"""
    return jsonify({
        'name': 'YatraAI Travel Booking API',
        'version': '1.0.0',
        'endpoints': {
            'auth': '/api/auth/*',
            'flights': '/api/flights/*',
            'trains': '/api/trains/*',
            'hotels': '/api/hotels/*',
            'packages': '/api/packages',
            'bookings': '/api/bookings/*',
            'payments': '/api/payments/*',
            'ai': '/api/ai/*'
        }
    })


@app.route('/api/health')
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()})


# ==================== DATABASE INITIALIZATION ====================

def init_db():
    """Initialize database with sample data"""
    with app.app_context():
        db.create_all()
        print("✅ Database tables created successfully!")


# ==================== MAIN ====================

if __name__ == '__main__':
    init_db()
    print("🚀 YatraAI Backend Server Starting...")
    print("📍 API running at http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
