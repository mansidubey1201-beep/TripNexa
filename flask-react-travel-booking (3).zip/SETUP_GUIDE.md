# 🚀 YatraAI - Complete Setup Guide

## 📋 Prerequisites

Before you begin, make sure you have the following installed:

### 1. Python (Version 3.8 or higher)
Download from: https://www.python.org/downloads/

**Verify installation:**
```bash
python --version
# or
python3 --version
```

### 2. pip (Python Package Manager)
Usually comes with Python. Verify:
```bash
pip --version
# or
pip3 --version
```

### 3. Git (Optional, for cloning)
Download from: https://git-scm.com/downloads

---

## 📁 Project Structure

```
YatraAI/
├── index.html              # Frontend (Single HTML file)
├── SETUP_GUIDE.md          # This file
├── backend/
│   ├── app.py              # Main Flask application
│   ├── models.py           # Database models
│   ├── config.py           # Configuration
│   ├── requirements.txt    # Python dependencies
│   └── README.md           # Backend documentation
```

---

## 🔧 Step-by-Step Setup

### Step 1: Create Project Folder

**Windows (Command Prompt):**
```cmd
mkdir YatraAI
cd YatraAI
```

**macOS/Linux (Terminal):**
```bash
mkdir YatraAI
cd YatraAI
```

---

### Step 2: Create Backend Folder

```bash
mkdir backend
cd backend
```

---

### Step 3: Create Virtual Environment (Recommended)

**Windows:**
```cmd
python -m venv venv
venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

You should see `(venv)` at the beginning of your terminal prompt.

---

### Step 4: Install Dependencies

Make sure you're in the `backend` folder with virtual environment activated:

```bash
pip install Flask==2.3.3 Flask-CORS==4.0.0 Flask-SQLAlchemy==3.0.5 Flask-JWT-Extended==4.5.3 Flask-Bcrypt==1.0.1 python-dotenv==1.0.0 requests==2.31.0 qrcode==7.4.2 Pillow==10.0.1
```

**Or using requirements.txt:**
```bash
pip install -r requirements.txt
```

---

### Step 5: Run the Backend Server

```bash
python app.py
```

You should see:
```
✅ Database tables created successfully!
🚀 YatraAI Backend Server Starting...
📍 API running at http://localhost:5000
 * Running on http://0.0.0.0:5000
 * Debug mode: on
```

**Keep this terminal open!** The backend needs to keep running.

---

### Step 6: Open the Frontend

**Option A: Simple Method**
1. Open a file explorer
2. Navigate to your `YatraAI` folder
3. Double-click on `index.html`
4. It will open in your default browser

**Option B: Using VS Code Live Server**
1. Install VS Code: https://code.visualstudio.com/
2. Install "Live Server" extension
3. Open `index.html` in VS Code
4. Right-click and select "Open with Live Server"

**Option C: Using Python HTTP Server**
Open a new terminal (keep backend running) and run:
```bash
cd YatraAI  # Go to main folder, not backend
python -m http.server 8080
```
Then open: http://localhost:8080

---

## ✅ Verify Everything is Working

### 1. Test Backend API
Open in browser: http://localhost:5000

You should see:
```json
{
  "name": "YatraAI Travel Booking API",
  "version": "1.0.0",
  "endpoints": {...}
}
```

### 2. Test Health Check
Open: http://localhost:5000/api/health

You should see:
```json
{
  "status": "healthy",
  "timestamp": "2024-..."
}
```

### 3. Test Frontend
- Open `index.html` in browser
- Click "Login" button in header
- Try registering a new account
- Search for flights/trains/hotels
- Try the AI Trip Planner

---

## 🧪 Testing the Application

### Test User Registration
1. Click "Login" button
2. Click "Register" tab
3. Fill in details:
   - Name: Test User
   - Email: test@example.com
   - Phone: 9876543210
   - Password: test123
   - City: Mumbai
   - State: Maharashtra
4. Check "I agree to Terms"
5. Click "Create Account"

### Test Flight Search
1. Go to Search section
2. Select "Flights" tab
3. Enter:
   - From: Delhi
   - To: Mumbai
   - Select a date
4. Click "Search"
5. View flight results

### Test Booking & Payment
1. Search for a flight/train/hotel
2. Click "Book" on any result
3. If not logged in, login first
4. Payment modal will appear
5. Choose payment method (UPI/Card/NetBanking)
6. Complete the simulated payment

### Test AI Trip Planner
1. Scroll to "Smart Trip Planner" section
2. Select destination (e.g., Jaipur)
3. Choose duration, budget, travelers
4. Select interests (Heritage, Food, etc.)
5. Click "Generate My Perfect Itinerary"
6. View the AI-generated trip plan

### Test AI Chat Assistant
1. Scroll to "AI Travel Saathi" section
2. Click any quick question or type your own
3. Examples:
   - "Best time to visit Ladakh?"
   - "Budget trip to Goa"
   - "Kerala food guide"

---

## 🔧 Troubleshooting

### Issue: "python not found"
**Solution:** 
- Windows: Use `python` or `py` instead of `python3`
- macOS/Linux: Use `python3` instead of `python`

### Issue: "pip not found"
**Solution:**
```bash
python -m pip install --upgrade pip
```

### Issue: "Module not found" errors
**Solution:**
```bash
pip install <module-name>
```

### Issue: Backend won't start (port in use)
**Solution:** Change port in `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```
Then update `API_URL` in `index.html`:
```javascript
const API_URL = 'http://localhost:5001/api';
```

### Issue: CORS errors in browser
**Solution:** Make sure Flask-CORS is installed:
```bash
pip install Flask-CORS
```

### Issue: Database errors
**Solution:** Delete the database and restart:
```bash
# In backend folder
rm yatraai.db  # Linux/macOS
del yatraai.db  # Windows
python app.py
```

### Issue: Frontend can't connect to backend
**Solution:**
1. Make sure backend is running (check terminal)
2. Check if you can access http://localhost:5000
3. Check browser console for errors (F12 → Console)

---

## 📱 Features to Test

### ✅ Authentication
- [x] User registration with email/phone
- [x] Login with email/password
- [x] OTP-based login (simulated)
- [x] Profile management
- [x] Logout

### ✅ Search & Booking
- [x] Flight search (Indian airlines)
- [x] Train search (IRCTC style)
- [x] Hotel search
- [x] Bus search
- [x] Package booking

### ✅ Payment
- [x] UPI QR code generation
- [x] UPI ID payment
- [x] Card payment (simulated)
- [x] Net banking (simulated)
- [x] Payment confirmation

### ✅ AI Features
- [x] AI Trip Planner
- [x] Chat Assistant (YatraBot)
- [x] Destination recommendations

---

## 🚀 Quick Start Commands

### Start Everything (Copy-Paste Ready)

**Terminal 1 - Backend:**
```bash
cd YatraAI/backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

**Terminal 2 - Frontend (Optional):**
```bash
cd YatraAI
python -m http.server 8080
# Open http://localhost:8080 in browser
```

---

## 📞 API Endpoints Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | API info |
| `/api/health` | GET | Health check |
| `/api/auth/register` | POST | Register user |
| `/api/auth/login` | POST | Login user |
| `/api/auth/send-otp` | POST | Send OTP |
| `/api/auth/verify-otp` | POST | Verify OTP |
| `/api/flights/search` | POST | Search flights |
| `/api/trains/search` | POST | Search trains |
| `/api/hotels/search` | POST | Search hotels |
| `/api/packages` | GET | Get packages |
| `/api/bookings` | POST | Create booking |
| `/api/bookings` | GET | Get user bookings |
| `/api/payments/initiate` | POST | Start payment |
| `/api/payments/verify` | POST | Verify payment |
| `/api/payments/generate-qr` | POST | Generate UPI QR |
| `/api/ai/chat` | POST | Chat with AI |
| `/api/ai/trip-plan` | POST | Generate trip plan |

---

## 🎉 You're All Set!

Your YatraAI travel booking platform is now running locally:

- **Backend API:** http://localhost:5000
- **Frontend:** Open `index.html` in browser

Enjoy exploring India with YatraAI! 🇮🇳

---

## 📧 Need Help?

If you encounter any issues:
1. Check the Troubleshooting section above
2. Check browser console (F12) for errors
3. Check terminal for Python errors
4. Make sure all dependencies are installed

Happy Traveling! 🧳✈️🚂
