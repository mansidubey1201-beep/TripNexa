#!/bin/bash

echo "============================================================"
echo "   YatraAI - AI Travel Booking Platform"
echo "   Quick Start Script for macOS/Linux"
echo "============================================================"
echo ""

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed!"
    echo "   Please install Python from https://www.python.org/downloads/"
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"
echo ""

# Navigate to script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR/backend"

if [ ! -f "app.py" ]; then
    echo "❌ app.py not found in backend folder!"
    exit 1
fi

echo "✅ Backend files found"
echo ""

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "📦 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📦 Installing dependencies..."
echo "----------------------------------------"
pip install Flask==2.3.3 Flask-CORS==4.0.0 Flask-SQLAlchemy==3.0.5 Flask-JWT-Extended==4.5.3 Flask-Bcrypt==1.0.1 python-dotenv==1.0.0 requests==2.31.0 qrcode==7.4.2 Pillow==10.0.1 -q

if [ $? -eq 0 ]; then
    echo "✅ All dependencies installed"
else
    echo "⚠️  Some packages may have failed to install"
fi

echo ""
echo "============================================================"
echo "   🚀 Starting YatraAI Backend Server..."
echo "============================================================"
echo ""
echo "   📍 API URL: http://localhost:5000"
echo "   📍 Health Check: http://localhost:5000/api/health"
echo ""
echo "   💡 Now open index.html in your browser!"
echo ""
echo "   Press Ctrl+C to stop the server"
echo "----------------------------------------"
echo ""

python3 app.py
