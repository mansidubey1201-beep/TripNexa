from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class User(db.Model):
    """User model for authentication"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(15), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    
    # Profile fields
    profile_picture = db.Column(db.String(500), nullable=True)
    date_of_birth = db.Column(db.Date, nullable=True)
    gender = db.Column(db.String(10), nullable=True)
    address = db.Column(db.Text, nullable=True)
    city = db.Column(db.String(50), nullable=True)
    state = db.Column(db.String(50), nullable=True)
    pincode = db.Column(db.String(10), nullable=True)
    
    # Relationships
    bookings = db.relationship('Booking', backref='user', lazy=True)
    payments = db.relationship('Payment', backref='user', lazy=True)
    saved_travelers = db.relationship('SavedTraveler', backref='user', lazy=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'phone': self.phone,
            'full_name': self.full_name,
            'created_at': self.created_at.isoformat(),
            'is_verified': self.is_verified,
            'profile_picture': self.profile_picture,
            'city': self.city,
            'state': self.state
        }


class SavedTraveler(db.Model):
    """Saved traveler details for quick booking"""
    __tablename__ = 'saved_travelers'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    id_type = db.Column(db.String(20), nullable=True)  # Aadhaar, PAN, Passport
    id_number = db.Column(db.String(50), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'full_name': self.full_name,
            'age': self.age,
            'gender': self.gender,
            'id_type': self.id_type,
            'id_number': self.id_number[:4] + '****' if self.id_number else None
        }


class Booking(db.Model):
    """Booking model for all travel bookings"""
    __tablename__ = 'bookings'
    
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.String(20), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Booking type: flight, train, hotel, bus, package
    booking_type = db.Column(db.String(20), nullable=False)
    
    # Common fields
    origin = db.Column(db.String(100), nullable=True)
    destination = db.Column(db.String(100), nullable=False)
    travel_date = db.Column(db.DateTime, nullable=False)
    return_date = db.Column(db.DateTime, nullable=True)
    
    # Travelers
    num_travelers = db.Column(db.Integer, default=1)
    traveler_details = db.Column(db.Text, nullable=True)  # JSON string
    
    # Pricing
    base_price = db.Column(db.Float, nullable=False)
    taxes = db.Column(db.Float, default=0)
    discount = db.Column(db.Float, default=0)
    total_price = db.Column(db.Float, nullable=False)
    
    # Status
    status = db.Column(db.String(20), default='pending')  # pending, confirmed, cancelled, completed
    
    # Additional details (JSON)
    booking_details = db.Column(db.Text, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    payment = db.relationship('Payment', backref='booking', uselist=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'booking_id': self.booking_id,
            'booking_type': self.booking_type,
            'origin': self.origin,
            'destination': self.destination,
            'travel_date': self.travel_date.isoformat() if self.travel_date else None,
            'return_date': self.return_date.isoformat() if self.return_date else None,
            'num_travelers': self.num_travelers,
            'traveler_details': json.loads(self.traveler_details) if self.traveler_details else [],
            'base_price': self.base_price,
            'taxes': self.taxes,
            'discount': self.discount,
            'total_price': self.total_price,
            'status': self.status,
            'booking_details': json.loads(self.booking_details) if self.booking_details else {},
            'created_at': self.created_at.isoformat(),
            'payment_status': self.payment.status if self.payment else 'unpaid'
        }


class Payment(db.Model):
    """Payment model for all transactions"""
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    payment_id = db.Column(db.String(30), unique=True, nullable=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Payment details
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='INR')
    
    # Payment method: upi, card, netbanking, wallet
    payment_method = db.Column(db.String(20), nullable=False)
    payment_provider = db.Column(db.String(50), nullable=True)  # GPay, PhonePe, Paytm, etc.
    
    # UPI specific
    upi_id = db.Column(db.String(100), nullable=True)
    upi_transaction_id = db.Column(db.String(50), nullable=True)
    
    # Card specific (only last 4 digits)
    card_last_four = db.Column(db.String(4), nullable=True)
    card_brand = db.Column(db.String(20), nullable=True)
    
    # Status
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed, refunded
    
    # Razorpay/Payment Gateway
    gateway_order_id = db.Column(db.String(50), nullable=True)
    gateway_payment_id = db.Column(db.String(50), nullable=True)
    gateway_signature = db.Column(db.String(100), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    
    # Refund details
    refund_amount = db.Column(db.Float, nullable=True)
    refund_status = db.Column(db.String(20), nullable=True)
    refund_id = db.Column(db.String(50), nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'payment_id': self.payment_id,
            'amount': self.amount,
            'currency': self.currency,
            'payment_method': self.payment_method,
            'payment_provider': self.payment_provider,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }


class Flight(db.Model):
    """Flight inventory"""
    __tablename__ = 'flights'
    
    id = db.Column(db.Integer, primary_key=True)
    flight_number = db.Column(db.String(10), nullable=False)
    airline = db.Column(db.String(50), nullable=False)
    origin = db.Column(db.String(10), nullable=False)
    destination = db.Column(db.String(10), nullable=False)
    departure_time = db.Column(db.String(10), nullable=False)
    arrival_time = db.Column(db.String(10), nullable=False)
    duration = db.Column(db.String(10), nullable=False)
    price = db.Column(db.Float, nullable=False)
    seats_available = db.Column(db.Integer, default=100)
    flight_class = db.Column(db.String(20), default='Economy')
    stops = db.Column(db.String(20), default='Non-stop')


class Train(db.Model):
    """Train inventory"""
    __tablename__ = 'trains'
    
    id = db.Column(db.Integer, primary_key=True)
    train_number = db.Column(db.String(10), nullable=False)
    train_name = db.Column(db.String(100), nullable=False)
    origin = db.Column(db.String(50), nullable=False)
    destination = db.Column(db.String(50), nullable=False)
    departure_time = db.Column(db.String(10), nullable=False)
    arrival_time = db.Column(db.String(10), nullable=False)
    duration = db.Column(db.String(15), nullable=False)
    running_days = db.Column(db.String(50), default='Daily')
    
    # Class-wise pricing and availability
    price_1a = db.Column(db.Float, nullable=True)
    price_2a = db.Column(db.Float, nullable=True)
    price_3a = db.Column(db.Float, nullable=True)
    price_sl = db.Column(db.Float, nullable=True)
    seats_1a = db.Column(db.Integer, default=20)
    seats_2a = db.Column(db.Integer, default=40)
    seats_3a = db.Column(db.Integer, default=60)
    seats_sl = db.Column(db.Integer, default=200)


class Hotel(db.Model):
    """Hotel inventory"""
    __tablename__ = 'hotels'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    city = db.Column(db.String(50), nullable=False)
    address = db.Column(db.Text, nullable=False)
    rating = db.Column(db.Float, default=4.0)
    review_count = db.Column(db.Integer, default=0)
    price_per_night = db.Column(db.Float, nullable=False)
    amenities = db.Column(db.Text, nullable=True)  # JSON array
    images = db.Column(db.Text, nullable=True)  # JSON array
    room_types = db.Column(db.Text, nullable=True)  # JSON array
    is_available = db.Column(db.Boolean, default=True)


class TravelPackage(db.Model):
    """Travel packages/combos"""
    __tablename__ = 'packages'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    duration = db.Column(db.String(20), nullable=False)
    price = db.Column(db.Float, nullable=False)
    discount_percent = db.Column(db.Integer, default=0)
    includes = db.Column(db.Text, nullable=True)  # JSON array
    itinerary = db.Column(db.Text, nullable=True)  # JSON array
    images = db.Column(db.Text, nullable=True)  # JSON array
    rating = db.Column(db.Float, default=4.5)
    review_count = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)


class OTP(db.Model):
    """OTP for phone/email verification"""
    __tablename__ = 'otps'
    
    id = db.Column(db.Integer, primary_key=True)
    phone_or_email = db.Column(db.String(120), nullable=False)
    otp_code = db.Column(db.String(6), nullable=False)
    purpose = db.Column(db.String(20), nullable=False)  # login, register, reset
    is_used = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
