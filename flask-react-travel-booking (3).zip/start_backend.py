#!/usr/bin/env python3
"""
YatraAI - Quick Start Script
Run this script to set up and start the backend server
"""

import subprocess
import sys
import os

def run_command(command, shell=True):
    """Run a command and return success status"""
    try:
        result = subprocess.run(command, shell=shell, check=True, capture_output=True, text=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr

def main():
    print("=" * 60)
    print("🪷  YatraAI - AI Travel Booking Platform")
    print("=" * 60)
    print()
    
    # Check Python version
    print("📌 Checking Python version...")
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required!")
        print(f"   Your version: {sys.version}")
        sys.exit(1)
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} detected")
    print()
    
    # Check if we're in the right directory
    backend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'backend')
    
    if not os.path.exists(backend_dir):
        print("❌ 'backend' folder not found!")
        print("   Make sure you're running this from the project root directory.")
        sys.exit(1)
    
    print(f"📂 Backend directory: {backend_dir}")
    print()
    
    # Change to backend directory
    os.chdir(backend_dir)
    
    # Install dependencies
    print("📦 Installing dependencies...")
    print("-" * 40)
    
    packages = [
        "Flask==2.3.3",
        "Flask-CORS==4.0.0", 
        "Flask-SQLAlchemy==3.0.5",
        "Flask-JWT-Extended==4.5.3",
        "Flask-Bcrypt==1.0.1",
        "python-dotenv==1.0.0",
        "requests==2.31.0",
        "qrcode==7.4.2",
        "Pillow==10.0.1"
    ]
    
    for package in packages:
        pkg_name = package.split("==")[0]
        print(f"   Installing {pkg_name}...", end=" ")
        success, output = run_command(f"{sys.executable} -m pip install {package} -q")
        if success:
            print("✅")
        else:
            print("❌")
            print(f"   Error: {output}")
    
    print()
    print("=" * 60)
    print("🚀 Starting YatraAI Backend Server...")
    print("=" * 60)
    print()
    print("📍 API URL: http://localhost:5000")
    print("📍 Health Check: http://localhost:5000/api/health")
    print()
    print("💡 Tips:")
    print("   - Keep this terminal open while using the app")
    print("   - Open index.html in your browser for the frontend")
    print("   - Press Ctrl+C to stop the server")
    print()
    print("-" * 60)
    print()
    
    # Run the Flask app
    try:
        subprocess.run([sys.executable, "app.py"], check=True)
    except KeyboardInterrupt:
        print("\n")
        print("👋 Server stopped. Thank you for using YatraAI!")
    except Exception as e:
        print(f"❌ Error starting server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
